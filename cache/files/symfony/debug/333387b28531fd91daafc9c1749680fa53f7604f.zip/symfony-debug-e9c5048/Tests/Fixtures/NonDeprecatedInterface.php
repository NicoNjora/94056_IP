<?php

namespace Symfony\Component\Debug\Tests\Fixtures;

interface NonDeprecatedInterface extends DeprecatedInterface
{
}
