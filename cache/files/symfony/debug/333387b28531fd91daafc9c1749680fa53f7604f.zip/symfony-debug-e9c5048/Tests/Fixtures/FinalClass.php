<?php

namespace Symfony\Component\Debug\Tests\Fixtures;

/**
 * @final since version 3.3.
 */
class FinalClass
{
}
