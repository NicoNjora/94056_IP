<?php
/**
 * @codeCoverageIgnore
 */
class IgnoreCodeCoverageClass
{
    public function returnTrue()
    {
        return true;
    }

    public function returnFalse()
    {
        return false;
    }
}
