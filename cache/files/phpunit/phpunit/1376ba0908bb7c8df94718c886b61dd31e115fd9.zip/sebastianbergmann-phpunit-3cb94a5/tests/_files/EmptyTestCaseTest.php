<?php
class EmptyTestCaseTest extends PHPUnit_Framework_TestCase
{
}
